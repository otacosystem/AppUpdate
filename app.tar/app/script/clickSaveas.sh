#!/bin/bash

xdotool mousemove 1900 965 click 1
sleep 0.5
xdotool mousemove 1170 520 click 1



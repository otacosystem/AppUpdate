#!/bin/bash

xdotool mousemove 1020 690 click 1
sleep 0.2
xdotool mousemove 1860 250 click 1
sleep 0.2
xdotool mousemove 1890 145 click 1
sleep 0.2
xdotool mousemove 1000 690 click 1
sleep 0.2
xdotool mousemove 1900 965 click 1
sleep 0.2
xdotool mousemove 1890 130 click 1
sleep 0.2
xdotool mousemove 1894 147 click 1
sleep 0.2
xdotool mousemove 1600 280 click 1
sleep 0.2
xdotool mousemove 1000 350 click 1



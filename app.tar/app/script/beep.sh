#!/bin/bash

play -n synth 0.1 sine 1000 vol 5

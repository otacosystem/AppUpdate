#!/bin/bash

sudo sh -c 'echo "0" > /sys/class/gpio/gpio2/value'


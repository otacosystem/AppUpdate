#!/bin/bash

echo 0 > /sys/class/gpio/gpio2/value


#!/bin/bash

sudo pkill uv4l

sudo depmod -a



#!/bin/bash

cat /sys/class/gpio/gpio26/value

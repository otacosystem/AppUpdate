#!/bin/bash

xdotool mousemove 1020 690 click 1
sleep 0.2
xdotool mousemove 1180 350 click 1
sleep 0.2
xdotool mousemove 1008 98 click 1



#!/bin/bash

xdotool mousemove 1180 350 click 1



#!/bin/bash

xdotool mousemove 1080 215 click 1



#!/bin/bash

cd /home/pi/otaco/app
java -jar UpdateAndRun.jar


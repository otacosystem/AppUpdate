#!/bin/bash

cd /media
sudo rm -r pi

cd /home/pi/otaco/app
java -jar UpdateAndRun.jar


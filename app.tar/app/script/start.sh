#!/bin/bash

cd /media
sudo rm -r pi
sudo mkdir pi


cd /home/pi/otaco/app
java -jar UpdateAndRun.jar


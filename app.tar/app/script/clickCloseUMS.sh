#!/bin/bash

xdotool mousemove 1000 690 click 1



#!/bin/bash

sudo cp -f /home/pi/otaco/app/kpop.tar /usr/share/uv4l/demos/kpop.tar
cd /usr/share/uv4l/demos
sudo tar xf kpop.tar

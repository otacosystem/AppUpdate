#!/bin/bash

lsusb | grep 'Logitech'


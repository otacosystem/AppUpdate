#!/bin/bash

sudo rm -r /home/pi/Downloads/*


#!/bin/bash

xdotool mousemove 1898 972 click 1



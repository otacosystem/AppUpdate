#!/bin/bash

cat /sys/class/gpio/gpio17/value

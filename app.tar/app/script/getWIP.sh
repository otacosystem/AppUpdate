#!/bin/bash

ifconfig wlan0


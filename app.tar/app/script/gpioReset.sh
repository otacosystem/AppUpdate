#!/bin/bash

sudo sh -c 'echo "17" > /sys/class/gpio/unexport'
sudo sh -c 'echo "27" > /sys/class/gpio/unexport'
sudo sh -c 'echo "22" > /sys/class/gpio/unexport'
sudo sh -c 'echo "26" > /sys/class/gpio/unexport'
sudo sh -c 'echo "4" > /sys/class/gpio/unexport'
sudo sh -c 'echo "2" > /sys/class/gpio/unexport'



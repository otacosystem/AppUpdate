#!/bin/bash

echo 17 > /sys/class/gpio/unexport
echo 27 > /sys/class/gpio/unexport
echo 22 > /sys/class/gpio/unexport
echo 26 > /sys/class/gpio/unexport
echo 4 > /sys/class/gpio/unexport
echo 2 > /sys/class/gpio/unexport


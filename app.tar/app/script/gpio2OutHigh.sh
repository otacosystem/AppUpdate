#!/bin/bash

echo 1 > /sys/class/gpio/gpio2/value


#!/bin/bash

sudo sh -c 'echo "1" > /sys/class/gpio/gpio2/value'


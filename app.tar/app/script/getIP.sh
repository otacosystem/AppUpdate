#!/bin/bash

ifconfig eth0


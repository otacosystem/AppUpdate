#!/bin/bash

cd /home/pi/otaco/app
java -jar testLinux.jar


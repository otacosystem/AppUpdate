#!/bin/bash

cd /home/pi/otaco
sudo tar xf app.tar

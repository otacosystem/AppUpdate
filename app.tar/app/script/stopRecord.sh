#!/bin/bash

sudo pkill ffmpeg


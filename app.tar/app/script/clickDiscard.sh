#!/bin/bash

xdotool mousemove 1580 215 click 1



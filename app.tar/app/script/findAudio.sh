#!/bin/bash

arecord -L | grep CARD

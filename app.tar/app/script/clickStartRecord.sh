#!/bin/bash

xdotool mousemove 1000 520 click 1



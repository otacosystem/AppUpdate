#!/bin/bash

xdotool mousemove 1480 215 click 1



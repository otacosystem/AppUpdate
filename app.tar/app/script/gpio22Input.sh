#!/bin/bash

cat /sys/class/gpio/gpio22/value

#!/bin/bash

chromium-browser --disable-notifications --no-sandbox --window-size=1000,960 --window-position=920,0 http://localhost



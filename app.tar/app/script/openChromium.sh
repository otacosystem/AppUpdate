#!/bin/bash

xdotool mousemove 1898 64 click 1
sleep 0.2
chromium-browser --disable-notifications --no-sandbox --window-size=1000,960 --window-position=920,0 http://localhost



#!/bin/bash

sudo pkill uv4l

sudo depmod -a

sudo modprobe uvcvideo

ffmpeg -y -ar 44100 -ac 2 -f alsa -i hw:1 -f v4l2 -i /dev/video0 -s 640x480 -c:v h264_omx /media/pi/E44C-4843/mv.mpg
#!/bin/bash

ffmpeg -y -f v4l2 -s 800x600 -i /dev/video0 /media/pi/A261-C7CD/mv12-10-39.mpg
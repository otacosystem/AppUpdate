#!/bin/bash

sudo pkill uv4l

sudo depmod -a

sleep 3

sudo modprobe uvcvideo

v4l2-ctl --device /dev/video0 --set-fmt-video=width=1920,height=1080,pixelformat=MJPG

ffmpeg -y -f v4l2 -s 800x600 -i /dev/video0 /media/pi/165F-D3D9/mv16-32-32.mpg
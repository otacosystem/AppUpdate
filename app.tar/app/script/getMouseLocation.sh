#!/bin/bash

while [ 1 ];
do
	xdotool getmouselocation
	sleep 0.5
done


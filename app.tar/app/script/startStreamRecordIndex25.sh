#!/bin/bash

uv4l --driver uvc --device-id 046d:0892 --config-file=/etc/uv4l/uv4l-uvc-recordIndex25.conf

#!/bin/bash

sudo sh -c 'echo "1" > /sys/class/gpio/gpio4/value'

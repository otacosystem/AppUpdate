#!/bin/bash

xdotool mousemove 1860 250 click 1
sleep 0.2
xdotool mousemove 1890 145 click 1
sleep 0.2
xdotool mousemove 1010 100 click 1
sleep 0.1
xdotool mousemove 1395 65 click 10


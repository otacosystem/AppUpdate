#!/bin/bash

sudo sh -c 'echo "17" > /sys/class/gpio/export'
sudo sh -c 'echo "27" > /sys/class/gpio/export'
sudo sh -c 'echo "22" > /sys/class/gpio/export'
sudo sh -c 'echo "26" > /sys/class/gpio/export'
sudo sh -c 'echo "4" > /sys/class/gpio/export'
sudo sh -c 'echo "2" > /sys/class/gpio/export'

sudo sh -c 'echo "in" > /sys/class/gpio/gpio17/direction'
sudo sh -c 'echo "in" > /sys/class/gpio/gpio27/direction'
sudo sh -c 'echo "in" > /sys/class/gpio/gpio22/direction'
sudo sh -c 'echo "in" > /sys/class/gpio/gpio26/direction'

sudo sh -c 'echo "out" > /sys/class/gpio/gpio4/direction'
sudo sh -c 'echo "out" > /sys/class/gpio/gpio2/direction'



#!/bin/bash

echo 17 > /sys/class/gpio/export
echo 27 > /sys/class/gpio/export
echo 22 > /sys/class/gpio/export
echo 26 > /sys/class/gpio/export
echo 4 > /sys/class/gpio/export
echo 2 > /sys/class/gpio/export

echo in > /sys/class/gpio/gpio17/direction
echo in > /sys/class/gpio/gpio27/direction
echo in > /sys/class/gpio/gpio22/direction
echo in > /sys/class/gpio/gpio26/direction

echo out > /sys/class/gpio/gpio4/direction
echo out > /sys/class/gpio/gpio2/direction


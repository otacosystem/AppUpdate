#!/bin/bash

cat /sys/class/gpio/gpio27/value
